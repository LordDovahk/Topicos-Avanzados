// Ejemplo de endpoint en Spring Boot
@RestController
@RequestMapping("/api")
public class PacienteController {

    @Autowired
    private PacienteRepository repository;

    @GetMapping("/pacientes")
    public ResponseEntity<List<Paciente>> getPacientes(
            @RequestHeader("Authorization") String token) {
        
        if (!validarToken(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(repository.findAll());
    }
}