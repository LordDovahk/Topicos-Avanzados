// src/main/java/model/DatabaseConnection.java
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://TU_IP_SERVIDOR:3306/hospital";
        String user = "admin1";
        String password = "Admin1Secure$123";
        String params = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        
        return DriverManager.getConnection(url + params, user, password);
    }
}