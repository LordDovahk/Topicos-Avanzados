// src/main/java/com/example/myapp/MainActivity.java
package com.example.myapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.DatabaseConnection;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> pacientesList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        listView = findViewById(R.id.listView);
        
        // Cargar datos en segundo plano
        new LoadPacientesTask().execute();
    }

    private class LoadPacientesTask extends AsyncTask<Void, Void, Boolean> {
        private String errorMessage = "";

        @Override
        protected Boolean doInBackground(Void... voids) {
            try (Connection con = DatabaseConnection.getConnection();
                 Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM pacientes")) {
                
                while (rs.next()) {
                    String paciente = rs.getInt("id") + " - " +
                                     rs.getString("nombre") + " " +
                                     rs.getString("apellido") + " (" +
                                     rs.getString("diagnostico") + ")";
                    pacientesList.add(paciente);
                }
                return true;
                
            } catch (SQLException e) {
                errorMessage = e.getMessage();
                Log.e("DB_ERROR", "Error de base de datos", e);
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        pacientesList
                );
                listView.setAdapter(adapter);
            } else {
                Toast.makeText(MainActivity.this, 
                              "Error: " + errorMessage, 
                              Toast.LENGTH_LONG).show();
            }
        }
    }
}