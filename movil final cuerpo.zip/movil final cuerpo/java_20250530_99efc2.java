new LoadPacientesTask().execute();

private class LoadPacientesTask extends AsyncTask<Void, Void, List<Paciente>> {
    protected List<Paciente> doInBackground(Void... voids) {
        try {
            return ApiClient.getApiService()
                    .getPacientes("Bearer " + getToken())
                    .execute()
                    .body();
        } catch (IOException e) {
            Log.e("API_ERROR", "Error: ", e);
            return null;
        }
    }

    protected void onPostExecute(List<Paciente> pacientes) {
        if (pacientes != null) {
            // Actualizar UI
        } else {
            Toast.makeText(MainActivity.this, 
                          "Error cargando datos", 
                          Toast.LENGTH_SHORT).show();
        }
    }
}