// En Android
public interface ApiService {
    @GET("api/pacientes")
    Call<List<Paciente>> getPacientes(@Header("Authorization") String token);
}

// Uso
Retrofit retrofit = new Retrofit.Builder()
        .baseUrl("https://tudominio.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build();

ApiService service = retrofit.create(ApiService.class);
Call<List<Paciente>> call = service.getPacientes("Bearer " + authToken);