public class Paciente {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String diagnostico;
    
    // Getters y setters
}