package controller;

import model.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;

/**
 * Controlador para ejecutar consultas SQL y mostrar resultados en una tabla.
 */
public class MainController {
    private final JTextArea queryArea;   // Área de texto para escribir consultas SQL
    private final JTable resultTable;     // Tabla para mostrar resultados

    /**
     * Constructor que inicializa los componentes de la vista.
     * @param queryArea Área de texto para ingresar consultas.
     * @param resultTable Tabla para mostrar resultados.
     */
    public MainController(JTextArea queryArea, JTable resultTable) {
        this.queryArea = queryArea;
        this.resultTable = resultTable;
    }

    /**
     * Ejecuta la consulta SQL ingresada en el área de texto.
     * - Convierte el ResultSet en datos para la tabla.
     * - Maneja errores de SQL con mensajes emergentes.
     */
    public void ejecutarConsulta() {
        String query = queryArea.getText();

        try (
            Statement stmt = DatabaseConnection.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery(query)  // Ejecuta la consulta
        ) {
            // Obtiene metadatos para los nombres de columnas
            ResultSetMetaData metaData = rs.getMetaData();
            Vector<String> columnNames = new Vector<>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));  // Nombre de cada columna
            }

            // Construye los datos de la tabla fila por fila
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));  // Valor de cada celda
                }
                data.add(row);
            }

            // Actualiza la tabla con el nuevo modelo de datos
            DefaultTableModel model = new DefaultTableModel(data, columnNames);
            resultTable.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la consulta: " + e.getMessage());
        }
    }
}