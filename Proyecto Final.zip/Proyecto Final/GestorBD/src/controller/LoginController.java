package controller;

import view.LoginView;
import view.MainView;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

/**
 * Controlador para la vista de inicio de sesión (LoginView).
 * Gestiona la lógica de autenticación de usuarios.
 */
public class LoginController {
    private final LoginView view;  // Vista asociada al controlador
    
    /**
     * Constructor que inicializa el controlador y configura el listener del botón.
     * @param view Vista de login (LoginView) a controlar.
     */
    public LoginController(LoginView view) {
        this.view = view;
        this.view.addLoginListener(this::autenticar);  // Vincula el botón al método autenticar
    }
    
    /**
     * Valida las credenciales del usuario.
     * - Si son correctas: Abre la ventana principal (MainView) y cierra el login.
     * - Si son incorrectas: Muestra un mensaje de error.
     * @param e Evento de acción del botón (no utilizado directamente).
     */
    private void autenticar(ActionEvent e) {
        String usuario = view.getUsuario();
        String password = view.getPassword();
        
        // Validación de credenciales (usuario: "admin", contraseña: "admin123")
        if ("admin".equals(usuario) && "admin123".equals(password)) {
            // Crea y muestra MainView en el hilo de eventos de Swing
            java.awt.EventQueue.invokeLater(() -> {
                new MainView().setVisible(true);  // Línea 27: Inicia la ventana principal
            });
            view.dispose();  // Cierra la ventana de login
        } else {
            JOptionPane.showMessageDialog(view, "Credenciales inválidas");
        }
    }
}