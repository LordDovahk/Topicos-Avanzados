import view.LoginView;
import controller.LoginController;

/**
 * Punto de entrada principal de la aplicación.
 * Inicia la interfaz gráfica en el hilo de eventos de Swing.
 */
public class App {
    public static void main(String[] args) {
        // Ejecuta la creación de la GUI en el hilo de eventos
        java.awt.EventQueue.invokeLater(() -> {
            LoginView view = new LoginView();  // Crea la ventana de login
            new LoginController(view);          // Asocia el controlador
            view.setVisible(true);              // Muestra la ventana
        });
    }
}