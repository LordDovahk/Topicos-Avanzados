package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Gestiona la conexión a la base de datos MySQL.
 * Patrón: Singleton (una única instancia de conexión).
 */
public class DatabaseConnection {
    /**
     * Obtiene una conexión a la base de datos "hospital".
     * @return Connection objeto de conexión JDBC.
     * @throws SQLException Si hay errores de conexión.
     */
    public static Connection getConnection() throws SQLException {
        // Parámetros de conexión actualizados (usuario/contraseña seguros)
        String url = "jdbc:mysql://localhost:3306/hospital";
        String user = "admin1";                   // Usuario con privilegios
        String password = "Admin1Secure$123";     // Contraseña segura
        
        // Configuración adicional para evitar problemas comunes
        String params = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        
        return DriverManager.getConnection(url + params, user, password);
    }
}