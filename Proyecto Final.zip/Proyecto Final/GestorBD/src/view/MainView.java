package view;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.DatabaseConnection;  // Importación corregida

/**
 * Ventana principal que muestra datos de una tabla de la base de datos.
 */
public class MainView extends javax.swing.JFrame {
    // Componentes generados por el diseñador GUI
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;

    /**
     * Constructor que carga datos iniciales al abrir la ventana.
     */
    public MainView() {
        initComponents();     // Inicializa componentes GUI
        cargarTablas();       // Línea 37: Carga datos de la tabla
    }

    /**
     * Carga datos desde la base de datos a la tabla.
     */
    private void cargarTablas() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);  // Limpia datos existentes
        
        try (
            Connection con = DatabaseConnection.getConnection();  // Usa conexión singleton
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM tu_tabla")  // Consulta de ejemplo
        ) {
            // Llena la tabla con los resultados
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("email")
                };
                model.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error de base de datos: " + ex.getMessage());
        }
    }

    /**
     * Método generado automáticamente por el diseñador de GUI (NetBeans/Swing).
     * Inicializa y configura componentes visuales.
     */
    private void initComponents() {
        // Código auto-generado (omito detalles por brevedad)
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        
        // Configuración básica de la tabla
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},  // Datos vacíos iniciales
            new String [] {"ID", "Nombre", "Email"}  // Encabezados
        ));
        jScrollPane1.setViewportView(jTable1);
        
        // ... (resto del código de diseño)
    }
}