package view;

import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

/**
 * Ventana de inicio de sesión con campos de usuario/contraseña.
 */
public class LoginView extends JFrame {
    // Componentes de la interfaz
    private final JTextField txtUsuario = new JTextField(10);
    private final JPasswordField txtPassword = new JPasswordField(10);
    private final JButton btnLogin = new JButton("Ingresar");

    /**
     * Configura la ventana de login.
     */
    public LoginView() {
        setTitle("Login");
        setLayout(new GridLayout(3, 2));  // Diseño de cuadrícula
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Cierra la app al salir
        
        // Agrega componentes a la ventana
        add(new JLabel("Usuario:"));
        add(txtUsuario);
        add(new JLabel("Contraseña:"));
        add(txtPassword);
        add(new JLabel());  // Espacio vacío
        add(btnLogin);
        
        pack();                   // Ajusta tamaño automático
        setLocationRelativeTo(null);  // Centra en pantalla
    }
    
    // Métodos de acceso a los datos
    public String getUsuario() {
        return txtUsuario.getText();
    }
    
    public String getPassword() {
        return new String(txtPassword.getPassword());  // Convierte char[] a String
    }
    
    /**
     * Asigna un listener al botón de login.
     * @param listener Acción a ejecutar al presionar el botón.
     */
    public void addLoginListener(ActionListener listener) {
        btnLogin.addActionListener(listener);
    }
    
    /**
     * Muestra un mensaje emergente.
     * @param mensaje Texto a mostrar.
     */
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
}